package com.green.hot;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HotMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hot_activity_hot_main);
    }
}
